const GAME_SECONDS = 20;
const WIN_SCORE = 15;
const MAX_BUBBLES = 8;
const MIN_BUBBLE_LIFE = 2300;
const MAX_BUBBLE_LIFE = 3200;

const LEVELS = [
  { min: 0, title: '小魚', emoji: '🐟', stars: '⭐' },
  { min: 8, title: '兔子', emoji: '🐰', stars: '⭐⭐' },
  { min: 15, title: '獅子', emoji: '🦁', stars: '⭐⭐⭐' }
];

const bubbleColors = [
  'rgba(120, 218, 255, 0.72)',
  'rgba(255, 164, 211, 0.72)',
  'rgba(169, 238, 143, 0.72)',
  'rgba(255, 221, 112, 0.72)',
  'rgba(190, 169, 255, 0.72)'
];

const startScreen = document.getElementById('startScreen');
const gameScreen = document.getElementById('gameScreen');
const resultScreen = document.getElementById('resultScreen');
const playArea = document.getElementById('playArea');
const timeLeftEl = document.getElementById('timeLeft');
const scoreEl = document.getElementById('score');
const resultEmoji = document.getElementById('resultEmoji');
const resultTitle = document.getElementById('resultTitle');
const starsEl = document.getElementById('stars');
const resultMessage = document.getElementById('resultMessage');
const kingMessage = document.getElementById('kingMessage');
const confettiLayer = document.getElementById('confettiLayer');
const startButton = document.getElementById('startButton');
const restartButton = document.getElementById('restartButton');
const soundButton = document.getElementById('soundButton');
const soundButtonGame = document.getElementById('soundButtonGame');

let score = 0;
let generatedCount = 0;
let poppedCount = 0;
let secondsLeft = GAME_SECONDS;
let gameTimer = null;
let spawnTimer = null;
let gameActive = false;
let soundOn = true;
let audioContext = null;

function showScreen(screen) {
  startScreen.classList.add('hidden');
  gameScreen.classList.add('hidden');
  resultScreen.classList.add('hidden');
  screen.classList.remove('hidden');
}

function updateSoundButtons() {
  soundButton.textContent = soundOn ? '🔊 音效開' : '🔇 音效關';
  soundButtonGame.textContent = soundOn ? '🔊' : '🔇';
}

function toggleSound() {
  soundOn = !soundOn;
  updateSoundButtons();
}

function ensureAudioContext() {
  if (!audioContext) {
    audioContext = new (window.AudioContext || window.webkitAudioContext)();
  }
  if (audioContext.state === 'suspended') {
    audioContext.resume();
  }
}

function playPopSound() {
  if (!soundOn) return;
  ensureAudioContext();

  const now = audioContext.currentTime;
  const oscillator = audioContext.createOscillator();
  const gain = audioContext.createGain();

  oscillator.type = 'sine';
  oscillator.frequency.setValueAtTime(720, now);
  oscillator.frequency.exponentialRampToValueAtTime(1180, now + 0.08);

  gain.gain.setValueAtTime(0.0001, now);
  gain.gain.exponentialRampToValueAtTime(0.18, now + 0.01);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.11);

  oscillator.connect(gain);
  gain.connect(audioContext.destination);
  oscillator.start(now);
  oscillator.stop(now + 0.12);
}

function playWinSound() {
  if (!soundOn) return;
  ensureAudioContext();

  const notes = [523.25, 659.25, 783.99, 1046.5];
  notes.forEach((frequency, index) => {
    const now = audioContext.currentTime + index * 0.12;
    const oscillator = audioContext.createOscillator();
    const gain = audioContext.createGain();

    oscillator.type = 'triangle';
    oscillator.frequency.setValueAtTime(frequency, now);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.16, now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.16);

    oscillator.connect(gain);
    gain.connect(audioContext.destination);
    oscillator.start(now);
    oscillator.stop(now + 0.18);
  });
}

function getBubbleLimit() {
  const elapsed = GAME_SECONDS - secondsLeft;
  if (elapsed < 7) return 3;
  if (elapsed < 14) return 5;
  return MAX_BUBBLES;
}

function getLevel(scoreValue) {
  return LEVELS.reduce((best, level) => {
    return scoreValue >= level.min ? level : best;
  }, LEVELS[0]);
}

function randomBetween(min, max) {
  return Math.random() * (max - min) + min;
}

function makeBubble() {
  if (!gameActive) return;

  const currentBubbles = playArea.querySelectorAll('.bubble').length;
  if (currentBubbles >= getBubbleLimit()) return;

  const bubble = document.createElement('button');
  bubble.className = 'bubble';
  bubble.type = 'button';
  bubble.setAttribute('aria-label', '泡泡');

  const playRect = playArea.getBoundingClientRect();
  const size = randomBetween(76, 122);
  const topSafe = 86;
  const x = randomBetween(8, Math.max(8, playRect.width - size - 8));
  const y = randomBetween(topSafe, Math.max(topSafe, playRect.height - size - 16));
  const color = bubbleColors[Math.floor(Math.random() * bubbleColors.length)];
  const floatDuration = randomBetween(1.6, 2.6);

  bubble.style.setProperty('--size', `${size}px`);
  bubble.style.setProperty('--bubble-color', color);
  bubble.style.setProperty('--float-duration', `${floatDuration}s`);
  bubble.style.left = `${x}px`;
  bubble.style.top = `${y}px`;

  bubble.dataset.popped = 'false';
  generatedCount += 1;

  bubble.addEventListener('pointerdown', () => popBubble(bubble), { once: true });
  playArea.appendChild(bubble);

  const life = randomBetween(MIN_BUBBLE_LIFE, MAX_BUBBLE_LIFE);
  window.setTimeout(() => {
    if (bubble.parentElement && bubble.dataset.popped === 'false') {
      bubble.remove();
      fillBubbles();
    }
  }, life);
}

function popBubble(bubble) {
  if (!gameActive || bubble.dataset.popped === 'true') return;

  bubble.dataset.popped = 'true';
  score += 1;
  poppedCount += 1;
  scoreEl.textContent = score;
  playPopSound();
  showSparkle(bubble);

  bubble.classList.add('pop');
  window.setTimeout(() => {
    bubble.remove();
    fillBubbles();
  }, 180);
}

function showSparkle(bubble) {
  const sparkle = document.createElement('div');
  sparkle.className = 'sparkle';
  sparkle.textContent = Math.random() > 0.5 ? '✨' : '💖';

  const rect = bubble.getBoundingClientRect();
  const areaRect = playArea.getBoundingClientRect();
  sparkle.style.left = `${rect.left - areaRect.left + rect.width / 2}px`;
  sparkle.style.top = `${rect.top - areaRect.top + rect.height / 2}px`;

  playArea.appendChild(sparkle);
  window.setTimeout(() => sparkle.remove(), 600);
}

function fillBubbles() {
  if (!gameActive) return;

  const limit = getBubbleLimit();
  const currentBubbles = playArea.querySelectorAll('.bubble').length;
  const need = limit - currentBubbles;

  for (let i = 0; i < need; i += 1) {
    window.setTimeout(makeBubble, i * 120);
  }
}

function startGame() {
  ensureAudioContext();

  score = 0;
  generatedCount = 0;
  poppedCount = 0;
  secondsLeft = GAME_SECONDS;
  gameActive = true;

  scoreEl.textContent = score;
  timeLeftEl.textContent = secondsLeft;
  playArea.innerHTML = '';
  confettiLayer.innerHTML = '';
  kingMessage.classList.add('hidden');

  showScreen(gameScreen);
  fillBubbles();

  spawnTimer = window.setInterval(fillBubbles, 700);
  gameTimer = window.setInterval(() => {
    secondsLeft -= 1;
    timeLeftEl.textContent = secondsLeft;

    if (secondsLeft <= 0) {
      endGame();
    }
  }, 1000);
}

function endGame() {
  gameActive = false;
  window.clearInterval(gameTimer);
  window.clearInterval(spawnTimer);

  const remainingBubbles = playArea.querySelectorAll('.bubble').length;
  const isBubbleKing = generatedCount > 0 && poppedCount === generatedCount;
  const level = getLevel(score);

  resultEmoji.textContent = isBubbleKing ? '🫧👑' : level.emoji;
  resultTitle.textContent = isBubbleKing ? '你是泡泡王' : level.title;
  starsEl.textContent = isBubbleKing ? '⭐⭐⭐' : level.stars;
  resultMessage.textContent = `你點到 ${score} 顆泡泡！`;

  if (isBubbleKing) {
    kingMessage.classList.remove('hidden');
  } else {
    kingMessage.classList.add('hidden');
  }

  playArea.innerHTML = '';
  showScreen(resultScreen);

  if (score >= WIN_SCORE || isBubbleKing) {
    launchConfetti();
    playWinSound();
  }

  // 保留這行只是方便日後除錯，不會顯示在畫面上。
  console.log({ generatedCount, poppedCount, remainingBubbles, isBubbleKing });
}

function launchConfetti() {
  confettiLayer.innerHTML = '';

  for (let i = 0; i < 90; i += 1) {
    const piece = document.createElement('div');
    piece.className = 'confetti';
    piece.style.left = `${Math.random() * 100}%`;
    piece.style.setProperty('--hue', `${Math.floor(Math.random() * 360)}`);
    piece.style.setProperty('--fall-duration', `${randomBetween(1.8, 3.4)}s`);
    piece.style.animationDelay = `${randomBetween(0, 0.7)}s`;
    piece.style.transform = `rotate(${Math.random() * 180}deg)`;
    confettiLayer.appendChild(piece);
  }

  window.setTimeout(() => {
    confettiLayer.innerHTML = '';
  }, 4400);
}

startButton.addEventListener('click', startGame);
restartButton.addEventListener('click', startGame);
soundButton.addEventListener('click', toggleSound);
soundButtonGame.addEventListener('click', toggleSound);
updateSoundButtons();
